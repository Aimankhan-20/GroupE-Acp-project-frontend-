import React, { useState } from 'react';
import './Testimonials.css';
import TestimonialsHero from './TestimonialsHero';
import TestimonialsFooter from './TestimonialsFooter';

import image6 from './Images/image6.jpg';
import image5 from './Images/image5.jpg';
import image2 from './Images/image2.jpg';

import appDownloadImage from './Images/app-download.png'; // Import the app download image

const initialReviews = [
    {
        id: 1,
        name: 'Laura Olister',
        review:
            'I ordered food from two different restaurants at the same time which are far from each other but the guys did very well and delivered the food on time hot and fresh. Everything was tasty and beautiful as in the restaurant. Food has not lost its beautiful appearance.',
        image: image6,
    },
    {
        id: 2,
        name: 'David Smith',
        review:
            'Very fast delivery. I recommend to everyone. The food is very hot and fresh and also as tasty as in a restaurant. The application is very convenient and understandable.',
        image: image5,
    },
    {
        id: 3,
        name: 'Emily Johnson',
        review:
            'The food was amazing! I really enjoyed the service and the quality of the ingredients. Will definitely order again soon.',
        image: image2,
    },
];

const Testimonials = () => {
    const [reviews, setReviews] = useState(initialReviews);
    const [newReview, setNewReview] = useState({
        name: '',
        email: '',
        review: '',
    });

    const [showOptions, setShowOptions] = useState(null);

    const handleInputChange = (e) => {
        setNewReview({ ...newReview, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!newReview.name || !newReview.email || !newReview.review) {
            alert('Please fill in all fields.');
            return;
        }

        const newReviewToAdd = {
            id: Date.now(),
            name: newReview.name,
            review: newReview.review,
            image: '/UserPhoto/default.png',
        };

        setReviews([newReviewToAdd, ...reviews]);
        setNewReview({ name: '', email: '', review: '' });
    };

    const handleDeleteReview = (id) => {
        setReviews(reviews.filter((review) => review.id !== id));
        setShowOptions(null);
    };

    return (
        <div className="testimonials-container">
            <TestimonialsHero />
            <h1 className="testimonials-heading">Our Clients Review</h1>
            <div className="content-wrapper">
                <div className="reviews-container">
                    {reviews.map((review) => (
                        <div key={review.id} className="review-card">
                            <div className="review-options">
                                <span className="dots" onClick={() => setShowOptions(review.id) === review.id ? null : review.id}>
                                    ...
                                </span>
                                {showOptions === review.id && (
                                    <div className="options">
                                        <button onClick={() => handleDeleteReview(review.id)}>Delete</button>
                                    </div>
                                )}
                            </div>
                            <div className="review-header">
                                <img src={review.image} alt={review.name} className="review-image" />
                                <div className="review-info">
                                    <h3 className="review-name">{review.name}</h3>
                                </div>
                            </div>
                            <p className="review-text">{review.review}</p>
                        </div>
                    ))}
                </div>
                <div className="right-side-content">
                    <div className="review-form">
                        <h3>Leave a Review</h3>
                        <form onSubmit={handleSubmit}>
                            <input
                                type="text"
                                name="name"
                                placeholder="Name"
                                value={newReview.name}
                                onChange={handleInputChange}
                                required
                            />
                            <input
                                type="email"
                                name="email"
                                placeholder="Email"
                                value={newReview.email}
                                onChange={handleInputChange}
                                required
                            />
                            <textarea
                                name="review"
                                placeholder="Write a review"
                                value={newReview.review}
                                onChange={handleInputChange}
                                required
                            />
                            <button type="submit">Submit</button>
                        </form>
                    </div>
                    <h4 className="app-download-text">Download The App</h4>
                    <img src={appDownloadImage} alt="Download App" className="app-download-image" />
                </div>
            </div>
            <TestimonialsFooter  /> 
        </div>
    );
};

export default Testimonials;
