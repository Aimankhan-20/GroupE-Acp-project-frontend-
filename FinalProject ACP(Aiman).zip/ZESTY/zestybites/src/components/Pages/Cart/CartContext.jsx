// CartContext.js (Updated with Backend Integration)
import React, { createContext, useContext, useState, useEffect } from 'react';
import { cartApi } from '../services/cartApi';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Load cart items from backend on component mount
  useEffect(() => {
    fetchCartItems();
  }, []);
  
  // Fetch cart items from backend
  const fetchCartItems = async () => {
    try {
      setLoading(true);
      const response = await cartApi.getCartItems();
      setCartItems(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch cart items:', error);
      setError('Failed to load cart items. Please try again later.');
      setLoading(false);
    }
  };
  
  // Add item to cart
  const addToCart = async (item) => {
    try {
      setLoading(true);
      const response = await cartApi.addToCart(item);
      setCartItems(response.data);
      setLoading(false);
      return response;
    } catch (error) {
      console.error('Failed to add item to cart:', error);
      setError('Failed to add item to cart. Please try again.');
      setLoading(false);
      return { success: false, error };
    }
  };
  
  // Remove item from cart
  const removeFromCart = async (itemId) => {
    try {
      setLoading(true);
      const response = await cartApi.removeFromCart(itemId);
      setCartItems(response.data);
      setLoading(false);
      return response;
    } catch (error) {
      console.error('Failed to remove item from cart:', error);
      setError('Failed to remove item from cart. Please try again.');
      setLoading(false);
      return { success: false, error };
    }
  };
  
  // Update item quantity
  const updateQuantity = async (itemId, newQuantity) => {
    try {
      setLoading(true);
      const response = await cartApi.updateCartItem(itemId, newQuantity);
      setCartItems(response.data);
      setLoading(false);
      return response;
    } catch (error) {
      console.error('Failed to update item quantity:', error);
      setError('Failed to update item quantity. Please try again.');
      setLoading(false);
      return { success: false, error };
    }
  };
  
  // Get total number of items in cart
  const getTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };
  
  // Get total price of all items in cart
  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
  };
  
  // Clear all errors
  const clearError = () => {
    setError(null);
  };

  return (
    <CartContext.Provider 
      value={{ 
        cartItems, 
        loading,
        error,
        addToCart, 
        removeFromCart, 
        updateQuantity,
        getTotalItems,
        getTotalPrice,
        clearError
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);