import React from 'react';
import { useCart } from '../RestaurantsDetails/CartContext/CartContext';
import './Cart.css'; // CSS file import karen

function Cart() {
  const { cart, increaseQuantity, decreaseQuantity, removeFromCart } = useCart();

  return (
    <div className="cart-container">
      <table className="cart-table">
        <thead>
          <tr className="cart-header">
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Subtotal</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cart.length === 0 ? (
            <tr>
              <td colSpan={5} className="empty-cart">Your cart is empty.</td>
            </tr>
          ) : (
            cart.map((item) => (
              <tr key={item.id} className="cart-item">
                <td className="product-cell">
                  <div className="product-info">
                    <img src={item.image} alt={item.name} className="product-image" />
                    <div className="product-details">
                      <p className="product-name">{item.name}</p>
                      <small className="product-meta">{item.weight || '200'} g / {item.calories || '354'} kcal</small>
                    </div>
                  </div>
                </td>
                <td className="quantity-cell">
                  <div className="quantity-controls">
                    <button 
                      className="quantity-btn decrease"
                      onClick={() => decreaseQuantity(item.id)} 
                      disabled={item.quantity === 1}
                    >
                      -
                    </button>
                    <span className="quantity-value">{item.quantity}</span>
                    <button 
                      className="quantity-btn increase"
                      onClick={() => increaseQuantity(item.id)}
                    >
                      +
                    </button>
                  </div>
                </td>
                <td className="price-cell">${Number(item.price).toFixed(2)}</td>
                <td className="subtotal-cell">${(Number(item.price) * item.quantity).toFixed(2)}</td>
                <td className="action-cell">
                  <button 
                    className="remove-btn" 
                    onClick={() => removeFromCart(item.id)}
                  >
                    ❌
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Cart;