// controllers/cartController.js
let cartItems = [];  // In-memory storage for cart items (for development)

// Get all cart items
exports.getCartItems = (req, res) => {
  console.log('Fetching all cart items');
  res.status(200).json({
    success: true,
    count: cartItems.length,
    data: cartItems
  });
};

// Add item to cart
exports.addToCart = (req, res) => {
  try {
    const { item } = req.body;
    
    if (!item || !item.name || !item.price) {
      return res.status(400).json({
        success: false,
        message: 'Please provide valid item details'
      });
    }
    
    // Check if item already exists in cart
    const existingItemIndex = cartItems.findIndex(
      cartItem => cartItem.name === item.name
    );
    
    if (existingItemIndex > -1) {
      // Update quantity if item already exists
      cartItems[existingItemIndex].quantity += 1;
      console.log(`Updated in cart: ${item.name}, New quantity: ${cartItems[existingItemIndex].quantity}`);
    } else {
      // Add new item to cart
      const newItem = { 
        ...item, 
        id: Date.now().toString(), // Generate unique ID
        quantity: 1 
      };
      cartItems.push(newItem);
      console.log(`Added to cart: ${newItem.name}, Price: ${newItem.price}`);
    }
    
    // Log current cart state
    console.log('Current Cart Items:');
    cartItems.forEach(item => {
      console.log(`- ${item.name}: ${item.quantity} x $${item.price} = $${(item.quantity * item.price).toFixed(2)}`);
    });
    
    res.status(201).json({
      success: true,
      data: cartItems
    });
  } catch (error) {
    console.error('Error adding item to cart:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// Update cart item quantity
exports.updateCartItem = (req, res) => {
  try {
    const { itemId, quantity } = req.body;
    
    if (!itemId || !quantity) {
      return res.status(400).json({
        success: false,
        message: 'Please provide item ID and quantity'
      });
    }
    
    const itemIndex = cartItems.findIndex(item => item.id === itemId);
    
    if (itemIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Item not found in cart'
      });
    }
    
    if (quantity < 1) {
      // Remove item if quantity is less than 1
      cartItems = cartItems.filter(item => item.id !== itemId);
      console.log(`Removed from cart: ${itemId}`);
    } else {
      // Update quantity
      cartItems[itemIndex].quantity = quantity;
      console.log(`Updated quantity: ${cartItems[itemIndex].name}, New quantity: ${quantity}`);
    }
    
    res.status(200).json({
      success: true,
      data: cartItems
    });
  } catch (error) {
    console.error('Error updating cart item:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// Remove item from cart
exports.removeFromCart = (req, res) => {
  try {
    const { itemId } = req.params;
    
    const itemToRemove = cartItems.find(item => item.id === itemId);
    
    if (!itemToRemove) {
      return res.status(404).json({
        success: false,
        message: 'Item not found in cart'
      });
    }
    
    // Remove item from cart
    cartItems = cartItems.filter(item => item.id !== itemId);
    console.log(`Removed from cart: ${itemToRemove.name}`);
    
    res.status(200).json({
      success: true,
      data: cartItems
    });
  } catch (error) {
    console.error('Error removing item from cart:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// Get cart total
exports.getCartTotal = (req, res) => {
  try {
    // Calculate total items and price
    const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
    const totalPrice = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    console.log(`Cart Summary - Total Items: ${totalItems}, Total Price: $${totalPrice.toFixed(2)}`);
    
    res.status(200).json({
      success: true,
      data: {
        totalItems,
        totalPrice: totalPrice.toFixed(2)
      }
    });
  } catch (error) {
    console.error('Error calculating cart total:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};