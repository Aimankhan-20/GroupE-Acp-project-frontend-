import React, { createContext, useState, useContext } from 'react';

// Create the context
export const CartContext = createContext();

// Create the provider
export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  // Add item to cart
  const addToCart = (item) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.name === item.name);
      if (existing) {
        return prev.map(i =>
          i.name === item.name ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  // Remove item from cart
  const removeFromCart = (itemName) => {
    setCartItems(prev => prev.filter(i => i.name !== itemName));
  };

  // Increase item quantity
  const increaseQuantity = (itemName) => {
    setCartItems(prev =>
      prev.map(i =>
        i.name === itemName ? { ...i, quantity: i.quantity + 1 } : i
      )
    );
  };

  // Decrease item quantity (min 0)
  const decreaseQuantity = (itemName) => {
    setCartItems(prev =>
      prev.map(i =>
        i.name === itemName
          ? { ...i, quantity: Math.max(i.quantity - 1, 0) }
          : i
      )
    );
  };

  // Get total price of cart
  const getTotalPrice = () => {
    return cartItems.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
  };

  // Clear entire cart
  const clearCart = () => {
    setCartItems([]);
  };

  // Context value
  const contextValue = {
    cartItems,
    addToCart,
    removeFromCart,
    increaseQuantity,
    decreaseQuantity,
    getTotalPrice,
    clearCart,
  };

  return (
    <CartContext.Provider value={contextValue}>
      {children}
    </CartContext.Provider>
  );
};

// Custom hook to use the cart context
export const useCart = () => useContext(CartContext);
