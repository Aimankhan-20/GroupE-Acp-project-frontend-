import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import { CartContext } from "./CartContext";
import CheckoutCard from "./CheckoutCard/CheckoutCard";
import CouponComponent from "./CouponComponent/CouponComponent";
import "./Cart.css";

const DELIVERY_FEE = 5.0; // example fixed delivery fee

const Cart = () => {
  const {
    cartItems,
    removeFromCart,
    increaseQuantity,
    decreaseQuantity,
    getTotalPrice,
    clearCart,
  } = useContext(CartContext);

  const [discountPercent, setDiscountPercent] = useState(0);

  // React Router navigation
  const navigate = useNavigate();

  // Function to apply discount from coupon component
  const applyDiscount = (percent) => {
    setDiscountPercent(percent);
  };

  // Calculate subtotal (before discount and delivery)
  const subtotal = getTotalPrice();

  // Calculate discount amount
  const discountAmount = (subtotal * discountPercent) / 100;

  // Calculate total after discount + delivery fee
  const total = subtotal - discountAmount + DELIVERY_FEE;

  return (
    <div className="cart-container">
      <h1 className="cart-heading">Your Cart</h1>
      {cartItems.length === 0 ? (
        <p className="empty-cart-message">Your cart is empty.</p>
      ) : (
        <>
          <div className="cart-items">
            {cartItems.map((item) => (
              <div className="cart-item" key={item.name}>
                <img
                  src={item.image}
                  alt={item.name}
                  className="product-image"
                />
                <div className="product-details">
                  <p className="product-name">{item.name}</p>
                  <p className="product-price">
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                </div>
                <div className="quantity-controls">
                  <button onClick={() => decreaseQuantity(item.name)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => increaseQuantity(item.name)}>+</button>
                </div>
                <button
                  className="remove-button"
                  onClick={() => removeFromCart(item.name)}
                  aria-label={`Remove ${item.name} from cart`}
                >
                  ❌
                </button>
              </div>
            ))}
          </div>

          {/* Coupon Component */}
          <CouponComponent total={subtotal} applyDiscount={applyDiscount} />

          {/* Checkout Summary */}
          <CheckoutCard
            subtotal={subtotal}
            deliveryFee={DELIVERY_FEE}
            total={total}
          />

          {/* Clear Cart / Checkout Button */}
          <div className="cart-summary">
            <button
              className="checkout-button"
              onClick={() => {
                navigate("/checkout"); // Go to checkout page
              }}
            >
              Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
